{{/*
common.configmap renders a ConfigMap from app.*, logLevel, logFormat, env.
Consumed by app charts via: {{ include "common.configmap" . }}
*/}}
{{- define "common.configmap" -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.app.name }}-config
  labels:
    app: {{ .Values.app.name }}
data:
  app.name: {{ .Values.app.name | quote }}
  app.version: {{ .Values.app.version | quote }}
  log.level: {{ .Values.logLevel | quote }}
  log.format: {{ .Values.logFormat | quote }}
  environment: {{ (first .Values.env).value | quote }}
{{- end -}}
